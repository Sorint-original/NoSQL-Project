Logins that should be used:
Regular employee, Username: E024; Password: Password123;
Admin, Username: E024; Password: Password123;